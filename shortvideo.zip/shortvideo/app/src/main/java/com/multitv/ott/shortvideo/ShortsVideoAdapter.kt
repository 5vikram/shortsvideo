package com.multitv.ott.shortvideo

class ShortsVideoAdapter {
}